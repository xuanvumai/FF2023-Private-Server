import pg from 'pg';
const { Pool } = pg;
if (!process.env.DATABASE_URL) throw new Error('Missing DATABASE_URL in .env');
export const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : undefined });
export async function query(text, params = []) { return pool.query(text, params); }
