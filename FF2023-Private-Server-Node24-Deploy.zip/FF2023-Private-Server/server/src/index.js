import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { createServer } from 'node:http';
import { WebSocketServer } from 'ws';
import { query, pool } from './db.js';

const app = express();
const httpServer = createServer(app);
const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET || JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be at least 32 characters');
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '32kb' }));

const asyncRoute = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'UNAUTHORIZED' }); }
}
function admin(req, res, next) {
  if (!process.env.ADMIN_KEY || req.headers['x-admin-key'] !== process.env.ADMIN_KEY) return res.status(403).json({ error: 'ADMIN_ONLY' });
  next();
}
function issueToken(user) { return jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, { expiresIn: '14d' }); }

app.get('/health', (_req, res) => res.json({ ok: true, service: 'FF2023 Private Server', node: process.version }));
app.post('/api/auth/register', asyncRoute(async (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  if (!/^[a-zA-Z0-9_]{3,24}$/.test(username) || password.length < 8) return res.status(400).json({ error: 'USERNAME_3_24_AND_PASSWORD_MIN_8_REQUIRED' });
  const hash = await bcrypt.hash(password, 12);
  try {
    const { rows } = await query('INSERT INTO users(username,password_hash) VALUES($1,$2) RETURNING id,username,level,xp,diamonds,coins', [username, hash]);
    const user = rows[0]; res.status(201).json({ token: issueToken(user), user });
  } catch (e) { if (e.code === '23505') return res.status(409).json({ error: 'USERNAME_TAKEN' }); throw e; }
}));
app.post('/api/auth/login', asyncRoute(async (req, res) => {
  const username = String(req.body.username || '').trim();
  const { rows } = await query('SELECT id,username,password_hash,level,xp,diamonds,coins FROM users WHERE username=$1', [username]);
  if (!rows[0] || !(await bcrypt.compare(String(req.body.password || ''), rows[0].password_hash))) return res.status(401).json({ error: 'INVALID_CREDENTIALS' });
  const { password_hash, ...user } = rows[0]; res.json({ token: issueToken(user), user });
}));
app.get('/api/me', auth, asyncRoute(async (req, res) => {
  const { rows } = await query('SELECT id,username,level,xp,diamonds,coins,created_at FROM users WHERE id=$1', [req.user.id]);
  if (!rows[0]) return res.status(404).json({ error: 'USER_NOT_FOUND' });
  res.json({ user: rows[0] });
}));
app.get('/api/inventory', auth, asyncRoute(async (req, res) => {
  const { rows } = await query('SELECT item_id,quantity FROM inventory WHERE user_id=$1 ORDER BY item_id', [req.user.id]);
  res.json({ items: rows });
}));
app.get('/api/shop', (_req, res) => res.json({ items: [
  { id: 'skin_training_01', name: 'Trang phục huấn luyện', price: 500, currency: 'coins', type: 'outfit' },
  { id: 'emote_wave_01', name: 'Emote chào', price: 250, currency: 'coins', type: 'emote' },
  { id: 'skin_weapon_01', name: 'Skin súng mẫu', price: 1000, currency: 'diamonds', type: 'weapon_skin' }
] }));
app.post('/api/shop/buy', auth, asyncRoute(async (req, res) => {
  const catalog = {
    skin_training_01: { price: 500, currency: 'coins' },
    emote_wave_01: { price: 250, currency: 'coins' },
    skin_weapon_01: { price: 1000, currency: 'diamonds' }
  };
  const item = catalog[String(req.body.itemId || '')];
  if (!item) return res.status(404).json({ error: 'ITEM_NOT_FOUND' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const wallet = await client.query('SELECT coins,diamonds FROM users WHERE id=$1 FOR UPDATE', [req.user.id]);
    if (!wallet.rows[0] || Number(wallet.rows[0][item.currency]) < item.price) { await client.query('ROLLBACK'); return res.status(400).json({ error: 'NOT_ENOUGH_CURRENCY' }); }
    await client.query(`UPDATE users SET ${item.currency}=${item.currency}-$1 WHERE id=$2`, [item.price, req.user.id]);
    await client.query('INSERT INTO inventory(user_id,item_id,quantity) VALUES($1,$2,1) ON CONFLICT(user_id,item_id) DO UPDATE SET quantity=inventory.quantity+1', [req.user.id, req.body.itemId]);
    await client.query('COMMIT'); res.json({ ok: true, itemId: req.body.itemId });
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}));
app.post('/api/matches/start', auth, asyncRoute(async (req, res) => {
  const mode = String(req.body.mode || 'battle_royale');
  if (!['battle_royale','clash_squad','training'].includes(mode)) return res.status(400).json({ error: 'INVALID_MODE' });
  const { rows } = await query('INSERT INTO matches(user_id,mode) VALUES($1,$2) RETURNING id,mode,created_at', [req.user.id, mode]);
  res.status(201).json({ match: rows[0], maxPlayers: mode === 'battle_royale' ? 50 : null, botsSupportedByClient: true });
}));
app.post('/api/matches/:id/complete', auth, asyncRoute(async (req, res) => {
  const placement = Math.max(1, Math.min(50, Number(req.body.placement || 50)));
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const m = await client.query('SELECT id,mode,completed FROM matches WHERE id=$1 AND user_id=$2 FOR UPDATE', [req.params.id, req.user.id]);
    if (!m.rows[0]) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'MATCH_NOT_FOUND' }); }
    if (m.rows[0].completed) { await client.query('ROLLBACK'); return res.status(409).json({ error: 'MATCH_ALREADY_COMPLETED' }); }
    // Reward rule requested for this private project: 1,000 diamonds per completed match.
    await client.query('UPDATE matches SET completed=true,placement=$1,completed_at=NOW() WHERE id=$2', [placement, req.params.id]);
    await client.query('UPDATE users SET diamonds=diamonds+1000,xp=xp+100 WHERE id=$1', [req.user.id]);
    await client.query(`INSERT INTO user_missions(user_id,mission_id,progress,claimed) VALUES($1,'complete_one_match',1,false) ON CONFLICT(user_id,mission_id) DO UPDATE SET progress=user_missions.progress+1 WHERE user_missions.claimed=false`, [req.user.id]);
    await client.query(`INSERT INTO user_missions(user_id,mission_id,progress,claimed) VALUES($1,'play_three_matches',1,false) ON CONFLICT(user_id,mission_id) DO UPDATE SET progress=user_missions.progress+1 WHERE user_missions.claimed=false`, [req.user.id]);
    await client.query('UPDATE users SET level=LEAST(100,1+FLOOR((xp+100)/500)::int) WHERE id=$1', [req.user.id]);
    await client.query('COMMIT');
    const { rows } = await client.query('SELECT level,xp,diamonds,coins FROM users WHERE id=$1', [req.user.id]);
    res.json({ ok: true, reward: { diamonds: 1000, xp: 100 }, user: rows[0] });
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}));
app.get('/api/missions', auth, asyncRoute(async (req, res) => {
  const { rows } = await query(`SELECT m.id,m.title,m.reward_diamonds,m.reward_coins,COALESCE(um.progress,0) progress,COALESCE(um.claimed,false) claimed FROM missions m LEFT JOIN user_missions um ON um.mission_id=m.id AND um.user_id=$1 WHERE m.active=true`, [req.user.id]);
  res.json({ missions: rows });
}));
app.post('/api/missions/:id/claim', auth, asyncRoute(async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const r = await client.query(`SELECT m.reward_diamonds,m.reward_coins,um.progress,um.claimed FROM missions m LEFT JOIN user_missions um ON um.mission_id=m.id AND um.user_id=$1 WHERE m.id=$2 AND m.active=true FOR UPDATE OF m`, [req.user.id, req.params.id]);
    const m = r.rows[0];
    const needed = req.params.id === 'play_three_matches' ? 3 : 1;
    if (!m || Number(m.progress || 0) < needed || m.claimed) { await client.query('ROLLBACK'); return res.status(400).json({ error: 'MISSION_NOT_READY_OR_CLAIMED' }); }
    await client.query('INSERT INTO user_missions(user_id,mission_id,progress,claimed) VALUES($1,$2,$3,true) ON CONFLICT(user_id,mission_id) DO UPDATE SET claimed=true', [req.user.id, req.params.id, m.progress]);
    await client.query('UPDATE users SET diamonds=diamonds+$1,coins=coins+$2 WHERE id=$3', [m.reward_diamonds,m.reward_coins,req.user.id]);
    await client.query('COMMIT'); res.json({ ok: true, reward: { diamonds: m.reward_diamonds, coins: m.reward_coins } });
  } catch(e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}));
app.get('/api/events', asyncRoute(async (_req, res) => {
  const { rows } = await query('SELECT id,title,description,starts_at,ends_at FROM events WHERE active=true AND (starts_at IS NULL OR starts_at<=NOW()) AND (ends_at IS NULL OR ends_at>=NOW()) ORDER BY starts_at NULLS FIRST');
  res.json({ events: rows });
}));
app.post('/api/admin/events', admin, asyncRoute(async (req, res) => {
  const { id, title, description = '', startsAt = null, endsAt = null } = req.body;
  if (!id || !title) return res.status(400).json({ error: 'ID_AND_TITLE_REQUIRED' });
  await query('INSERT INTO events(id,title,description,starts_at,ends_at,active) VALUES($1,$2,$3,$4,$5,true) ON CONFLICT(id) DO UPDATE SET title=EXCLUDED.title,description=EXCLUDED.description,starts_at=EXCLUDED.starts_at,ends_at=EXCLUDED.ends_at,active=true', [id,title,description,startsAt,endsAt]);
  res.status(201).json({ ok: true });
}));
app.post('/api/admin/grant', admin, asyncRoute(async (req, res) => {
  const username = String(req.body.username || '');
  const diamonds = Math.max(0, Math.min(1000000, Number(req.body.diamonds || 0)));
  const coins = Math.max(0, Math.min(1000000, Number(req.body.coins || 0)));
  const r = await query('UPDATE users SET diamonds=diamonds+$1,coins=coins+$2 WHERE username=$3 RETURNING username,diamonds,coins', [diamonds,coins,username]);
  if (!r.rows[0]) return res.status(404).json({ error: 'USER_NOT_FOUND' });
  res.json({ ok: true, user: r.rows[0] });
}));

wss.on('connection', (ws) => {
  ws.send(JSON.stringify({ type: 'connected', service: 'FF2023 Private Server' }));
  ws.on('message', (raw) => {
    // Realtime transport starter: validate and route game events here.
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'ping') ws.send(JSON.stringify({ type: 'pong', at: Date.now() }));
      else ws.send(JSON.stringify({ type: 'notice', message: 'Realtime gameplay handler not configured yet.' }));
    } catch { ws.send(JSON.stringify({ type: 'error', message: 'Invalid JSON' })); }
  });
});
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'INTERNAL_SERVER_ERROR' }); });
httpServer.listen(PORT, process.env.HOST || '0.0.0.0', () => console.log(`FF2023 server listening on http://localhost:${PORT}`));
process.on('SIGINT', async () => { await pool.end(); httpServer.close(() => process.exit(0)); });
