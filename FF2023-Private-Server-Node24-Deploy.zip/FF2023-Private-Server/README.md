# FF2023 Private Server — Node.js 24 starter

This is a starter backend for a separately developed, FF2023-inspired game. It is **not** a Garena server emulator, does not include Garena game assets, and does not modify or redirect the official FF2023 app. The playable iOS/Unity game client must be developed separately and explicitly call this API.

## Requirements
- Node.js 24.x (pinned to 24.21.0 for Render)
- PostgreSQL 14+

## Deploy to Render (iPhone-friendly)
1. Upload the extracted repository contents to GitHub. Keep `render.yaml` at the repository root and the backend in `server/`.
2. In Render, create a PostgreSQL database. Copy its **Internal Database URL**.
3. In Render choose **New + → Blueprint**, connect this GitHub repository, and apply `render.yaml`.
4. In the created web service's Environment settings, set `DATABASE_URL` to the Internal Database URL. Render generates `JWT_SECRET` and `ADMIN_KEY`; do not share them or commit them.
5. Deploy the service. For the first database initialization, open the service Shell (if available) and run `npm run db:init` from the service root (`server/`). If Shell is unavailable, run the SQL in `server/sql/schema.sql` using the database provider's SQL console.
6. Open `https://YOUR-SERVICE.onrender.com/health`. A successful response contains `ok: true` and the Node version.

The Render web service and PostgreSQL may incur charges depending on the plans selected. Check the current pricing and service limits before confirming creation. Do not paste secrets into GitHub or chat.

## Deploy manually instead of Blueprint
- Runtime: Node
- Root Directory: `server`
- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/health`
- Environment: `NODE_VERSION=24.21.0`, `HOST=0.0.0.0`, `PORT` supplied by host, `DATABASE_URL` from PostgreSQL, `JWT_SECRET` (random 32+ chars), `ADMIN_KEY` (separate random secret), `CORS_ORIGIN=*`, `PGSSL=true` for hosted PostgreSQL.

## Run locally
1. Install Node.js 24 and PostgreSQL.
2. Create a database named `ff2023`.
3. Copy `server/.env.example` to `server/.env`; set `DATABASE_URL`, `JWT_SECRET`, and `ADMIN_KEY`.
4. From `server/`, run `npm install`, `npm run db:init`, then `npm start`.
5. Check `http://127.0.0.1:3000/health`.

## API endpoints
- `GET /health`
- `POST /api/auth/register` `{ "username":"player01", "password":"password123" }`
- `POST /api/auth/login`
- `GET /api/me` (Bearer token)
- `GET /api/inventory` (Bearer token)
- `GET /api/shop`
- `POST /api/shop/buy` `{ "itemId":"skin_training_01" }` (Bearer token)
- `POST /api/matches/start` `{ "mode":"battle_royale" }` (Bearer token)
- `POST /api/matches/:id/complete` `{ "placement":1 }` (Bearer token)
- `GET /api/missions` and `POST /api/missions/:id/claim` (Bearer token)
- `GET /api/events`
- `POST /api/admin/grant` and `POST /api/admin/events` (header `x-admin-key`)
- WebSocket endpoint: `/ws`

## Current scope and limitations
The backend includes account registration/login, JWT auth, wallet/inventory, a placeholder shop, match records, missions, events, admin grants, and a basic WebSocket connection. It does **not** implement real-time 50-player combat, matchmaking, bots, maps, movement, weapons, rank, training island, full cosmetics, or the iOS game UI. Those require a separate Unity/iOS client and authoritative game simulation. Offline mode and bots must run in the client and save locally; server sync is possible when online.

The sample match-completion endpoint currently trusts client-reported completion and grants the sample reward configured in code. Do not expose competitive rewards to real players until server-authoritative match validation and anti-cheat checks are implemented. Sample shop item IDs are placeholders, not official Garena content.
